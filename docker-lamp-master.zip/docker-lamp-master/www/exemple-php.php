<!DOCTYPE html>
<html>
    <head>
        <title>Registre National</title>
    </head>
    <body>
        <h1>Registre National</h1>
        <!-- Insertion de code PHP -->
        <?php
        for ($i = 1; $i <= 4; $i++) {
            echo "<p>Paragraphe $i </p>";
        }
        ?>
    </body>
</html>