<footer>
    <hr>
    <a href="index.html"">Back to Index</a>
</footer>
</html>
